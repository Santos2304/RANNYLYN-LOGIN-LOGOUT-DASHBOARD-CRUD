﻿
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Ranny_Login
{
    public partial class DashboardForm : Form
    {
        private readonly string fullName;
        private readonly Color blue = Color.FromArgb(35, 105, 180);

        private DataGridView productGrid = null!, userGrid = null!;

        private TextBox txtProductName = null!;
        private TextBox txtDescription = null!;
        private TextBox txtPrice = null!;
        private TextBox txtQuantity = null!;
        private TextBox txtReorder = null!;
        private TextBox txtProductSearch = null!;

        private TextBox txtFullName = null!;
        private TextBox txtUsername = null!;
        private TextBox txtUserPassword = null!;
        private TextBox txtUserSearch = null!;

        private Label lblTotal = null!;
        private Label lblInStock = null!;
        private Label lblLowStock = null!;
        private Label lblOut = null!;

        private int selectedProductId = 0;
        private int selectedUserId = 0;

        public DashboardForm(string name)
        {
            InitializeComponent();

            fullName = name;

            BuildDashboard();

            Load += (_, _) =>
            {
                if (DatabaseHelper.TestConnection())
                {
                    LoadProducts();
                    LoadUsers();
                }
            };
        }

        private void DashboardForm_Load(object? sender, EventArgs e)
        {
        }

        // ==============================
        // MAIN DASHBOARD
        // ==============================

        private void BuildDashboard()
        {
            Text = "Ranny Login - Management Dashboard";

            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;
            MinimumSize = new Size(1000, 700);

            BackColor = Color.FromArgb(245, 247, 250);
            Font = new Font("Segoe UI", 9F);

            var header = new Panel
            {
                Dock = DockStyle.Top,
                Height = 62,
                BackColor = Color.White,
                Padding = new Padding(18, 10, 18, 8)
            };

            Controls.Add(header);

            var welcome = new Label
            {
                Text = "Welcome, " + fullName + "!",
                AutoSize = true,
                Font = new Font("Segoe UI", 15, FontStyle.Bold),
                ForeColor = Color.FromArgb(40, 50, 65),
                Location = new Point(18, 16)
            };

            header.Controls.Add(welcome);

            var logout = MakeButton(
                "Logout",
                Color.FromArgb(35, 55, 110),
                Color.White,
                95,
                34
            );

            logout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            logout.Location = new Point(Width - 145, 13);

            logout.Click += (_, _) =>
            {
                if (MessageBox.Show(
                    "Are you sure you want to logout?",
                    "Logout",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Close();
                }
            };

            header.Controls.Add(logout);

            header.Resize += (_, _) =>
            {
                logout.Location = new Point(
                    header.ClientSize.Width - logout.Width - 18,
                    13
                );
            };

            var tabs = new TabControl
            {
                Dock = DockStyle.Fill,
                Padding = new Point(16, 6)
            };

            Controls.Add(tabs);
            tabs.BringToFront();
            header.BringToFront();

            var productTab = new TabPage("Product Management")
            {
                BackColor = Color.FromArgb(245, 247, 250),
                Padding = new Padding(12)
            };

            var userTab = new TabPage("User Management")
            {
                BackColor = Color.FromArgb(245, 247, 250),
                Padding = new Padding(12)
            };

            tabs.TabPages.Add(productTab);
            tabs.TabPages.Add(userTab);

            BuildProducts(productTab);
            BuildUsers(userTab);
        }

        // ==============================
        // PRODUCT MANAGEMENT
        // ==============================

        private void BuildProducts(TabPage page)
        {
            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(4)
            };

            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 58));

            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 112));

            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 178));

            root.RowStyles.Add(
                new RowStyle(SizeType.Percent, 100));

            page.Controls.Add(root);

            root.Controls.Add(new Label
            {
                Text = "Product Management\nManage your inventory products",
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                ForeColor = Color.FromArgb(45, 55, 70),
                TextAlign = ContentAlignment.MiddleLeft
            }, 0, 0);

            // STATISTICS CARDS

            var cards = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 4,
                RowCount = 1,
                Padding = new Padding(0, 2, 0, 8)
            };

            for (int i = 0; i < 4; i++)
            {
                cards.ColumnStyles.Add(
                    new ColumnStyle(SizeType.Percent, 25));
            }

            root.Controls.Add(cards, 0, 1);

            lblTotal = AddStat(
                cards, "Total Products",
                Color.FromArgb(155, 184, 208), 0);

            lblInStock = AddStat(
                cards, "In Stock",
                Color.FromArgb(0, 220, 25), 1);

            lblLowStock = AddStat(
                cards, "Low Stock",
                Color.FromArgb(245, 190, 125), 2);

            lblOut = AddStat(
                cards, "Out of Stock",
                Color.FromArgb(235, 112, 128), 3);

            // PRODUCT INFORMATION

            var form = new GroupBox
            {
                Text = "Product Information",
                Dock = DockStyle.Fill,
                Padding = new Padding(10),
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };

            root.Controls.Add(form, 0, 2);

            txtProductName = AddInput(
                form, "Product Name", 12, 24, 240);

            txtDescription = AddInput(
                form, "Description", 12, 90, 240, true);

            txtPrice = AddInput(
                form, "Unit Price", 275, 24, 180);

            txtQuantity = AddInput(
                form, "Quantity", 475, 24, 150);

            txtReorder = AddInput(
                form, "Reorder Level", 645, 24, 145);

            var add = MakeButton(
                "Add Product",
                Color.LimeGreen,
                Color.Black,
                120,
                30
            );

            add.Location = new Point(820, 22);
            add.Click += AddProduct_Click;
            form.Controls.Add(add);

            var update = MakeButton(
                "Update",
                Color.DodgerBlue,
                Color.White,
                120,
                30
            );

            update.Location = new Point(820, 57);
            update.Click += UpdateProduct_Click;
            form.Controls.Add(update);

            var delete = MakeButton(
                "Delete",
                Color.FromArgb(225, 55, 65),
                Color.White,
                120,
                30
            );

            delete.Location = new Point(820, 92);
            delete.Click += DeleteProduct_Click;
            form.Controls.Add(delete);

            var clear = MakeButton(
                "Clear",
                Color.Gainsboro,
                Color.Black,
                120,
                30
            );

            clear.Location = new Point(820, 127);
            clear.Click += (_, _) => ClearProductFields();
            form.Controls.Add(clear);

            // Keep action buttons inside the Product Information area.
            void PositionProductButtons()
            {
                int buttonX = Math.Max(645, form.ClientSize.Width - add.Width - 18);
                add.Location = new Point(buttonX, 22);
                update.Location = new Point(buttonX, 57);
                delete.Location = new Point(buttonX, 92);
                clear.Location = new Point(buttonX, 127);
            }

            form.Resize += (_, _) => PositionProductButtons();
            PositionProductButtons();

            // PRODUCT LIST

            var list = new GroupBox
            {
                Text = "Product List",
                Dock = DockStyle.Fill,
                Padding = new Padding(10)
            };

            root.Controls.Add(list, 0, 3);

            var toolbar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 45
            };

            var refresh = MakeButton(
                "Refresh",
                Color.WhiteSmoke,
                blue,
                85,
                30
            );

            refresh.Location = new Point(10, 7);
            refresh.Click += (_, _) => LoadProducts();

            toolbar.Controls.Add(refresh);

            var searchLabel = new Label
            {
                Text = "Search",
                AutoSize = true,
                Location = new Point(610, 15)
            };

            toolbar.Controls.Add(searchLabel);

            txtProductSearch = new TextBox
            {
                Location = new Point(665, 10),
                Width = 250,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };

            txtProductSearch.TextChanged +=
                (_, _) => FilterGrid(productGrid, txtProductSearch.Text);

            toolbar.Controls.Add(txtProductSearch);

            void PositionProductSearch()
            {
                txtProductSearch.Width = Math.Min(250, Math.Max(150, toolbar.ClientSize.Width / 3));
                txtProductSearch.Location = new Point(
                    toolbar.ClientSize.Width - txtProductSearch.Width - 12, 10);
                searchLabel.Location = new Point(
                    txtProductSearch.Left - searchLabel.Width - 12, 15);
            }

            toolbar.Resize += (_, _) => PositionProductSearch();
            PositionProductSearch();

            productGrid = CreateGrid();
            productGrid.Dock = DockStyle.Fill;
            productGrid.ScrollBars = ScrollBars.Both;
            productGrid.SelectionChanged += ProductGrid_SelectionChanged;

            list.Controls.Add(productGrid);
            list.Controls.Add(toolbar);
        }

        // ==============================
        // STATISTICS CARDS
        // ==============================

        private Label AddStat(
            TableLayoutPanel parent,
            string title,
            Color color,
            int column)
        {
            var panel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = color,
                Margin = new Padding(5)
            };

            panel.Controls.Add(new Label
            {
                Text = title,
                Dock = DockStyle.Top,
                Height = 34,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            });

            var value = new Label
            {
                Text = "0",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 18, FontStyle.Bold)
            };

            panel.Controls.Add(value);
            parent.Controls.Add(panel, column, 0);

            return value;
        }

        // ==============================
        // USER MANAGEMENT
        // ==============================

        private void BuildUsers(TabPage page)
        {
            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(4)
            };

            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 58));

            root.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 145));

            root.RowStyles.Add(
                new RowStyle(SizeType.Percent, 100));

            page.Controls.Add(root);

            root.Controls.Add(new Label
            {
                Text = "User Management\nManage registered accounts",
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            });

            var form = new GroupBox
            {
                Text = "User Information",
                Dock = DockStyle.Fill,
                Padding = new Padding(10)
            };

            root.Controls.Add(form, 0, 1);

            txtFullName = AddInput(
                form, "Full Name", 12, 25, 220);

            txtUsername = AddInput(
                form, "Username", 250, 25, 200);

            txtUserPassword = AddInput(
                form,
                "Password (leave blank to keep current)",
                470, 25, 270
            );

            txtUserPassword.UseSystemPasswordChar = true;

            var add = MakeButton(
                "Add User",
                Color.LimeGreen,
                Color.Black,
                105,
                30
            );

            add.Location = new Point(770, 22);
            add.Click += AddUser_Click;
            form.Controls.Add(add);

            var update = MakeButton(
                "Update",
                Color.DodgerBlue,
                Color.White,
                105,
                30
            );

            update.Location = new Point(770, 57);
            update.Click += UpdateUser_Click;
            form.Controls.Add(update);

            var delete = MakeButton(
                "Delete",
                Color.FromArgb(225, 55, 65),
                Color.White,
                105,
                30
            );

            delete.Location = new Point(770, 92);
            delete.Click += DeleteUser_Click;
            form.Controls.Add(delete);

            var clear = MakeButton(
                "Clear",
                Color.Gainsboro,
                Color.Black,
                105,
                30
            );

            clear.Location = new Point(885, 92);
            clear.Click += (_, _) => ClearUserFields();
            form.Controls.Add(clear);

            // REGISTERED USERS LIST

            var list = new GroupBox
            {
                Text = "Registered Users",
                Dock = DockStyle.Fill,
                Padding = new Padding(10)
            };

            root.Controls.Add(list, 0, 2);

            var toolbar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 45
            };

            var refresh = MakeButton(
                "Refresh",
                Color.WhiteSmoke,
                blue,
                85,
                30
            );

            refresh.Location = new Point(10, 7);
            refresh.Click += (_, _) => LoadUsers();

            toolbar.Controls.Add(refresh);

            var searchLabel = new Label
            {
                Text = "Search",
                AutoSize = true,
                Location = new Point(610, 15)
            };

            toolbar.Controls.Add(searchLabel);

            txtUserSearch = new TextBox
            {
                Location = new Point(665, 10),
                Width = 250,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };

            txtUserSearch.TextChanged +=
                (_, _) => FilterGrid(userGrid, txtUserSearch.Text);

            toolbar.Controls.Add(txtUserSearch);

            void PositionUserSearch()
            {
                txtUserSearch.Width = Math.Min(250, Math.Max(150, toolbar.ClientSize.Width / 3));
                txtUserSearch.Location = new Point(
                    toolbar.ClientSize.Width - txtUserSearch.Width - 12, 10);
                searchLabel.Location = new Point(
                    txtUserSearch.Left - searchLabel.Width - 12, 15);
            }

            toolbar.Resize += (_, _) => PositionUserSearch();
            PositionUserSearch();

            userGrid = CreateGrid();
            userGrid.Dock = DockStyle.Fill;
            userGrid.ScrollBars = ScrollBars.Both;
            userGrid.SelectionChanged += UserGrid_SelectionChanged;

            list.Controls.Add(userGrid);
            list.Controls.Add(toolbar);
        }

        // ==============================
        // INPUT AND BUTTON HELPERS
        // ==============================

        private TextBox AddInput(
            Control parent,
            string label,
            int x,
            int y,
            int width,
            bool multiline = false)
        {
            parent.Controls.Add(new Label
            {
                Text = label,
                AutoSize = true,
                Location = new Point(x, y)
            });

            var t = new TextBox
            {
                Location = new Point(x, y + 22),
                Width = width,
                Height = multiline ? 58 : 27,
                Multiline = multiline,
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };

            parent.Controls.Add(t);

            return t;
        }

        private Button MakeButton(
            string text,
            Color back,
            Color fore,
            int width,
            int height)
        {
            return new Button
            {
                Text = text,
                Size = new Size(width, height),
                BackColor = back,
                ForeColor = fore,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
        }

        private DataGridView CreateGrid()
        {
            return new DataGridView
            {
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                RowHeadersVisible = false,
                Dock = DockStyle.Fill,
                ScrollBars = ScrollBars.Both,
                EnableHeadersVisualStyles = false,
                ColumnHeadersHeight = 32,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                RowTemplate = { Height = 28 },
                ColumnHeadersDefaultCellStyle =
                {
                    BackColor = Color.FromArgb(225, 232, 240),
                    Font = new Font("Segoe UI", 9, FontStyle.Bold)
                }
            };
        }

        // ==============================
        // LOAD PRODUCTS
        // ==============================

        private void LoadProducts()
        {
            try
            {
                DataTable dt = DatabaseHelper.GetProducts();

                productGrid.DataSource = dt;

                int total = dt.Rows.Count;
                int outCount = 0;
                int low = 0;
                int inStock = 0;

                foreach (DataRow r in dt.Rows)
                {
                    int q = Convert.ToInt32(r["Quantity"]);
                    int reorder = Convert.ToInt32(r["ReorderLevel"]);

                    if (q <= 0)
                        outCount++;
                    else if (q <= reorder)
                        low++;
                    else
                        inStock++;
                }

                lblTotal.Text = total.ToString();
                lblInStock.Text = inStock.ToString();
                lblLowStock.Text = low.ToString();
                lblOut.Text = outCount.ToString();

                if (productGrid.Columns.Contains("ProductID"))
                {
                    productGrid.Columns["ProductID"].Visible = false;
                }

                FilterGrid(productGrid, txtProductSearch.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Unable to load products: " + ex.Message);
            }
        }

        // ==============================
        // LOAD USERS
        // ==============================

        private void LoadUsers()
        {
            try
            {
                userGrid.DataSource = DatabaseHelper.GetUsers();

                if (userGrid.Columns.Contains("UserID"))
                {
                    userGrid.Columns["UserID"].Visible = false;
                }

                FilterGrid(userGrid, txtUserSearch.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Unable to load users: " + ex.Message);
            }
        }

        // ==============================
        // SEARCH FUNCTION
        // ==============================

        private void FilterGrid(DataGridView grid, string text)
        {
            if (grid.DataSource is not DataTable dt)
                return;

            if (string.IsNullOrWhiteSpace(text))
            {
                dt.DefaultView.RowFilter = "";
                return;
            }

            string safe = text
                .Replace("'", "''")
                .Replace("[", "[[]");

            string filter = "";

            foreach (DataColumn col in dt.Columns)
            {
                if (col.DataType == typeof(string))
                {
                    filter +=
                        (filter.Length > 0 ? " OR " : "") +
                        "Convert([" + col.ColumnName +
                        "], 'System.String') LIKE '%" +
                        safe + "%'";
                }
            }

            dt.DefaultView.RowFilter = filter;
        }

        // ==============================
        // PRODUCT CRUD
        // ==============================

        private void AddProduct_Click(object? sender, EventArgs e)
        {
            if (!ReadProduct(
                out string name,
                out string desc,
                out decimal price,
                out int qty,
                out int reorder))
                return;

            try
            {
                DatabaseHelper.AddProduct(
                    name, desc, price, qty, reorder);

                MessageBox.Show("Product added successfully.");

                LoadProducts();
                ClearProductFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Add product failed: " + ex.Message);
            }
        }

        private void UpdateProduct_Click(object? sender, EventArgs e)
        {
            if (selectedProductId == 0)
            {
                MessageBox.Show("Select a product from the list first.");
                return;
            }

            if (!ReadProduct(
                out string name,
                out string desc,
                out decimal price,
                out int qty,
                out int reorder))
                return;

            try
            {
                DatabaseHelper.UpdateProduct(
                    selectedProductId,
                    name,
                    desc,
                    price,
                    qty,
                    reorder
                );

                MessageBox.Show("Product updated.");

                LoadProducts();
                ClearProductFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update failed: " + ex.Message);
            }
        }

        private void DeleteProduct_Click(object? sender, EventArgs e)
        {
            if (selectedProductId == 0)
            {
                MessageBox.Show("Select a product first.");
                return;
            }

            if (MessageBox.Show(
                "Delete the selected product?",
                "Confirm",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            try
            {
                DatabaseHelper.DeleteProduct(selectedProductId);

                LoadProducts();
                ClearProductFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete failed: " + ex.Message);
            }
        }

        private bool ReadProduct(
            out string name,
            out string desc,
            out decimal price,
            out int qty,
            out int reorder)
        {
            name = txtProductName.Text.Trim();
            desc = txtDescription.Text.Trim();

            price = 0;
            qty = 0;
            reorder = 0;

            if (name.Length == 0 ||
                !decimal.TryParse(txtPrice.Text, out price) ||
                price < 0 ||
                !int.TryParse(txtQuantity.Text, out qty) ||
                qty < 0 ||
                !int.TryParse(txtReorder.Text, out reorder) ||
                reorder < 0)
            {
                MessageBox.Show(
                    "Enter a product name, valid non-negative price, quantity, and reorder level.");

                return false;
            }

            return true;
        }

        private void ProductGrid_SelectionChanged(
            object? sender,
            EventArgs e)
        {
            if (productGrid.CurrentRow == null ||
                productGrid.CurrentRow.IsNewRow)
                return;

            var r = productGrid.CurrentRow;

            if (r.Cells["ProductID"].Value == null)
                return;

            selectedProductId =
                Convert.ToInt32(r.Cells["ProductID"].Value);

            txtProductName.Text =
                Convert.ToString(r.Cells["ProductName"].Value) ?? "";

            txtDescription.Text =
                Convert.ToString(r.Cells["Description"].Value) ?? "";

            txtPrice.Text =
                Convert.ToString(r.Cells["UnitPrice"].Value) ?? "0";

            txtQuantity.Text =
                Convert.ToString(r.Cells["Quantity"].Value) ?? "0";

            txtReorder.Text =
                Convert.ToString(r.Cells["ReorderLevel"].Value) ?? "0";
        }

        private void ClearProductFields()
        {
            selectedProductId = 0;

            txtProductName.Clear();
            txtDescription.Clear();
            txtPrice.Clear();
            txtQuantity.Clear();
            txtReorder.Clear();

            productGrid.ClearSelection();
        }

        // ==============================
        // USER CRUD
        // ==============================

        private void AddUser_Click(object? sender, EventArgs e)
        {
            if (txtFullName.Text.Trim().Length == 0 ||
                txtUsername.Text.Trim().Length == 0 ||
                txtUserPassword.Text.Length < 8)
            {
                MessageBox.Show(
                    "Enter full name, username, and a password of at least 8 characters.");

                return;
            }

            try
            {
                if (!DatabaseHelper.AddUser(
                    txtFullName.Text.Trim(),
                    txtUsername.Text.Trim(),
                    txtUserPassword.Text))
                {
                    MessageBox.Show("Username already exists.");
                    return;
                }

                MessageBox.Show("User added successfully.");

                LoadUsers();
                ClearUserFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Add user failed: " + ex.Message);
            }
        }

        private void UpdateUser_Click(object? sender, EventArgs e)
        {
            if (selectedUserId == 0)
            {
                MessageBox.Show("Select a user from the list first.");
                return;
            }

            if (txtFullName.Text.Trim().Length == 0 ||
                txtUsername.Text.Trim().Length == 0 ||
                (txtUserPassword.Text.Length > 0 &&
                 txtUserPassword.Text.Length < 8))
            {
                MessageBox.Show(
                    "Enter a full name and username. A new password must have at least 8 characters.");

                return;
            }

            try
            {
                DatabaseHelper.UpdateUser(
                    selectedUserId,
                    txtFullName.Text.Trim(),
                    txtUsername.Text.Trim(),
                    txtUserPassword.Text
                );

                MessageBox.Show("User updated successfully.");

                LoadUsers();
                ClearUserFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update user failed: " + ex.Message);
            }
        }

        private void DeleteUser_Click(object? sender, EventArgs e)
        {
            if (selectedUserId == 0)
            {
                MessageBox.Show("Select a user first.");
                return;
            }

            if (MessageBox.Show(
                "Permanently delete this user account?",
                "Confirm",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            try
            {
                DatabaseHelper.DeleteUser(selectedUserId);

                LoadUsers();
                ClearUserFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete user failed: " + ex.Message);
            }
        }

        private void UserGrid_SelectionChanged(
            object? sender,
            EventArgs e)
        {
            if (userGrid.CurrentRow == null ||
                userGrid.CurrentRow.IsNewRow)
                return;

            var r = userGrid.CurrentRow;

            if (r.Cells["UserID"].Value == null)
                return;

            selectedUserId =
                Convert.ToInt32(r.Cells["UserID"].Value);

            txtFullName.Text =
                Convert.ToString(r.Cells["FullName"].Value) ?? "";

            txtUsername.Text =
                Convert.ToString(r.Cells["Username"].Value) ?? "";

            txtUserPassword.Clear();
        }

        private void ClearUserFields()
        {
            selectedUserId = 0;

            txtFullName.Clear();
            txtUsername.Clear();
            txtUserPassword.Clear();

            userGrid.ClearSelection();
        }
    }
}
