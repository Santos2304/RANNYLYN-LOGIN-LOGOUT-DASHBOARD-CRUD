﻿
using System;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Ranny_Login
{
    public static class DatabaseHelper
    {
        private static readonly string DbPath = ResolveDatabasePath();

        private static readonly string ConnectionString =
            $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={DbPath};Persist Security Info=False;";

        private static string ResolveDatabasePath()
        {
            string projectPath = Path.GetFullPath(
                Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "..", "..", "..", "rannydatabase.accdb"));

            string outputPath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "rannydatabase.accdb");

            if (File.Exists(projectPath))
                return projectPath;

            return outputPath;
        }

        public static OleDbConnection GetConnection()
        {
            if (!File.Exists(DbPath))
                throw new FileNotFoundException(
                    "Database not found: " + DbPath);

            return new OleDbConnection(ConnectionString);
        }

        public static bool TestConnection()
        {
            try
            {
                using var c = GetConnection();
                c.Open();

                EnsureProductsTable(c);

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Database connection failed:\n" + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return false;
            }
        }

        // DATABASE STRUCTURE HELPERS

        private static DataTable GetColumns(
            OleDbConnection c, string table)
        {
            return c.GetOleDbSchemaTable(
                OleDbSchemaGuid.Columns,
                new object?[] { null, null, table, null })
                ?? new DataTable();
        }

        private static bool HasColumn(
            DataTable columns, string name)
        {
            return columns.Rows.Cast<DataRow>().Any(r =>
                string.Equals(
                    Convert.ToString(r["COLUMN_NAME"]),
                    name,
                    StringComparison.OrdinalIgnoreCase));
        }

        private static void AddColumnIfMissing(
            OleDbConnection c,
            string table,
            string column,
            string dataType)
        {
            DataTable columns = GetColumns(c, table);

            if (!HasColumn(columns, column))
            {
                using var cmd = new OleDbCommand(
                    $"ALTER TABLE [{table}] ADD COLUMN [{column}] {dataType}",
                    c);

                cmd.ExecuteNonQuery();
            }
        }

        private static void EnsureProductsTable(OleDbConnection c)
        {
            DataTable tables = c.GetSchema("Tables");

            bool exists = tables.Rows.Cast<DataRow>().Any(r =>
                string.Equals(
                    Convert.ToString(r["TABLE_NAME"]),
                    "Products",
                    StringComparison.OrdinalIgnoreCase));

            if (!exists)
            {
                using var create = new OleDbCommand(
                    "CREATE TABLE Products (" +
                    "ProductID COUNTER PRIMARY KEY, " +
                    "ProductName TEXT(255), " +
                    "[Description] MEMO, " +
                    "Price CURRENCY, " +
                    "Stock LONG, " +
                    "ReorderLevel LONG, " +
                    "CreatedAt DATETIME)",
                    c);

                create.ExecuteNonQuery();
            }

            // Add missing columns without deleting existing data.
            AddColumnIfMissing(
                c, "Products", "Description", "MEMO");

            DataTable columns = GetColumns(c, "Products");

            if (!HasColumn(columns, "Price") &&
                !HasColumn(columns, "UnitPrice"))
            {
                AddColumnIfMissing(
                    c, "Products", "Price", "CURRENCY");
            }

            columns = GetColumns(c, "Products");

            if (!HasColumn(columns, "Stock") &&
                !HasColumn(columns, "Quantity"))
            {
                AddColumnIfMissing(
                    c, "Products", "Stock", "LONG");
            }

            AddColumnIfMissing(
                c, "Products", "ReorderLevel", "LONG");

            AddColumnIfMissing(
                c, "Products", "CreatedAt", "DATETIME");
        }

        private static string GetUserKeyColumn(OleDbConnection c)
        {
            DataTable keys = c.GetOleDbSchemaTable(
                OleDbSchemaGuid.Primary_Keys,
                new object?[] { null, null, "Users", null })
                ?? throw new InvalidOperationException(
                    "Cannot read Users primary key.");

            if (keys.Rows.Count == 0)
                throw new InvalidOperationException(
                    "The Users table needs a primary key.");

            return Convert.ToString(keys.Rows[0]["COLUMN_NAME"])
                ?? throw new InvalidOperationException(
                    "Users primary key is unavailable.");
        }

        // LOGIN AND REGISTRATION

        public static bool RegisterUser(
            string fullName,
            string username,
            string password)
        {
            using var c = GetConnection();
            c.Open();

            using var check = new OleDbCommand(
                "SELECT COUNT(*) FROM Users WHERE Username=?", c);

            check.Parameters.Add(
                "@p1", OleDbType.VarWChar).Value = username;

            if (Convert.ToInt32(check.ExecuteScalar()) > 0)
                return false;

            string salt = PasswordHasher.GenerateSalt();
            string hash = PasswordHasher.HashPassword(password, salt);

            using var cmd = new OleDbCommand(
                "INSERT INTO Users " +
                "(FullName, Username, PasswordHash, PasswordSalt, CreatedAt) " +
                "VALUES (?, ?, ?, ?, ?)", c);

            cmd.Parameters.Add(
                "@p1", OleDbType.VarWChar).Value = fullName;

            cmd.Parameters.Add(
                "@p2", OleDbType.VarWChar).Value = username;

            cmd.Parameters.Add(
                "@p3", OleDbType.VarWChar).Value = hash;

            cmd.Parameters.Add(
                "@p4", OleDbType.VarWChar).Value = salt;

            cmd.Parameters.Add(
                "@p5", OleDbType.Date).Value = DateTime.Now;

            return cmd.ExecuteNonQuery() > 0;
        }

        public static string? LoginUser(
            string username,
            string password)
        {
            using var c = GetConnection();
            c.Open();

            using var cmd = new OleDbCommand(
                "SELECT FullName, PasswordHash, PasswordSalt " +
                "FROM Users WHERE Username=?", c);

            cmd.Parameters.Add(
                "@p1", OleDbType.VarWChar).Value = username;

            using var reader = cmd.ExecuteReader();

            if (reader != null && reader.Read())
            {
                string name =
                    Convert.ToString(reader["FullName"]) ?? "";

                string hash =
                    Convert.ToString(reader["PasswordHash"]) ?? "";

                string salt =
                    Convert.ToString(reader["PasswordSalt"]) ?? "";

                if (hash.Length > 0 &&
                    salt.Length > 0 &&
                    PasswordHasher.VerifyPassword(password, salt, hash))
                {
                    return name;
                }
            }

            return null;
        }

        // USER MANAGEMENT

        public static DataTable GetUsers()
        {
            using var c = GetConnection();
            c.Open();

            string key = GetUserKeyColumn(c);

            using var da = new OleDbDataAdapter(
                $"SELECT [{key}] AS UserID, " +
                "FullName, Username, CreatedAt " +
                $"FROM Users ORDER BY [{key}] DESC",
                c);

            DataTable dt = new DataTable();
            da.Fill(dt);

            return dt;
        }

        public static bool AddUser(
            string fullName,
            string username,
            string password)
        {
            return RegisterUser(fullName, username, password);
        }

        public static bool UpdateUser(
            int id,
            string fullName,
            string username,
            string? newPassword)
        {
            using var c = GetConnection();
            c.Open();

            string key = GetUserKeyColumn(c);

            using var check = new OleDbCommand(
                $"SELECT COUNT(*) FROM Users " +
                $"WHERE Username=? AND [{key}]<>?",
                c);

            check.Parameters.Add(
                "@p1", OleDbType.VarWChar).Value = username;

            check.Parameters.Add(
                "@p2", OleDbType.Integer).Value = id;

            if (Convert.ToInt32(check.ExecuteScalar()) > 0)
                throw new InvalidOperationException(
                    "Username already exists.");

            using var cmd = new OleDbCommand();
            cmd.Connection = c;

            if (!string.IsNullOrWhiteSpace(newPassword))
            {
                string salt = PasswordHasher.GenerateSalt();
                string hash =
                    PasswordHasher.HashPassword(newPassword, salt);

                cmd.CommandText =
                    $"UPDATE Users SET FullName=?, Username=?, " +
                    $"PasswordHash=?, PasswordSalt=? WHERE [{key}]=?";

                cmd.Parameters.Add(
                    "@p1", OleDbType.VarWChar).Value = fullName;

                cmd.Parameters.Add(
                    "@p2", OleDbType.VarWChar).Value = username;

                cmd.Parameters.Add(
                    "@p3", OleDbType.VarWChar).Value = hash;

                cmd.Parameters.Add(
                    "@p4", OleDbType.VarWChar).Value = salt;

                cmd.Parameters.Add(
                    "@p5", OleDbType.Integer).Value = id;
            }
            else
            {
                cmd.CommandText =
                    $"UPDATE Users SET FullName=?, Username=? " +
                    $"WHERE [{key}]=?";

                cmd.Parameters.Add(
                    "@p1", OleDbType.VarWChar).Value = fullName;

                cmd.Parameters.Add(
                    "@p2", OleDbType.VarWChar).Value = username;

                cmd.Parameters.Add(
                    "@p3", OleDbType.Integer).Value = id;
            }

            return cmd.ExecuteNonQuery() > 0;
        }

        public static bool DeleteUser(int id)
        {
            using var c = GetConnection();
            c.Open();

            string key = GetUserKeyColumn(c);

            using var cmd = new OleDbCommand(
                $"DELETE FROM Users WHERE [{key}]=?", c);

            cmd.Parameters.Add(
                "@p1", OleDbType.Integer).Value = id;

            return cmd.ExecuteNonQuery() > 0;
        }

        // PRODUCT MANAGEMENT

        public static DataTable GetProducts()
        {
            using var c = GetConnection();
            c.Open();

            EnsureProductsTable(c);

            DataTable columns = GetColumns(c, "Products");

            string price = HasColumn(columns, "Price")
                ? "Price"
                : "UnitPrice";

            string quantity = HasColumn(columns, "Stock")
                ? "Stock"
                : "Quantity";

            using var da = new OleDbDataAdapter(
                "SELECT ProductID, ProductName, [Description], " +
                $"[{price}] AS UnitPrice, " +
                $"[{quantity}] AS Quantity, " +
                "IIf(IsNull(ReorderLevel), 0, ReorderLevel) AS ReorderLevel, " +
                "CreatedAt " +
                "FROM Products ORDER BY ProductID DESC",
                c);

            DataTable dt = new DataTable();
            da.Fill(dt);

            return dt;
        }

        public static void AddProduct(
            string name,
            string description,
            decimal price,
            int quantity,
            int reorder)
        {
            using var c = GetConnection();
            c.Open();

            EnsureProductsTable(c);

            DataTable columns = GetColumns(c, "Products");

            string priceCol = HasColumn(columns, "Price")
                ? "Price"
                : "UnitPrice";

            string quantityCol = HasColumn(columns, "Stock")
                ? "Stock"
                : "Quantity";

            using var cmd = new OleDbCommand(
                "INSERT INTO Products " +
                $"(ProductName, [Description], [{priceCol}], " +
                $"[{quantityCol}], ReorderLevel, CreatedAt) " +
                "VALUES (?, ?, ?, ?, ?, ?)",
                c);

            cmd.Parameters.Add(
                "@p1", OleDbType.VarWChar).Value = name;

            cmd.Parameters.Add(
                "@p2", OleDbType.LongVarWChar).Value = description;

            cmd.Parameters.Add(
                "@p3", OleDbType.Currency).Value = price;

            cmd.Parameters.Add(
                "@p4", OleDbType.Integer).Value = quantity;

            cmd.Parameters.Add(
                "@p5", OleDbType.Integer).Value = reorder;

            cmd.Parameters.Add(
                "@p6", OleDbType.Date).Value = DateTime.Now;

            cmd.ExecuteNonQuery();
        }

        public static bool UpdateProduct(
            int id,
            string name,
            string description,
            decimal price,
            int quantity,
            int reorder)
        {
            using var c = GetConnection();
            c.Open();

            EnsureProductsTable(c);

            DataTable columns = GetColumns(c, "Products");

            string priceCol = HasColumn(columns, "Price")
                ? "Price"
                : "UnitPrice";

            string quantityCol = HasColumn(columns, "Stock")
                ? "Stock"
                : "Quantity";

            using var cmd = new OleDbCommand(
                "UPDATE Products SET " +
                "ProductName=?, [Description]=?, " +
                $"[{priceCol}]=?, [{quantityCol}]=?, " +
                "ReorderLevel=? WHERE ProductID=?",
                c);

            cmd.Parameters.Add(
                "@p1", OleDbType.VarWChar).Value = name;

            cmd.Parameters.Add(
                "@p2", OleDbType.LongVarWChar).Value = description;

            cmd.Parameters.Add(
                "@p3", OleDbType.Currency).Value = price;

            cmd.Parameters.Add(
                "@p4", OleDbType.Integer).Value = quantity;

            cmd.Parameters.Add(
                "@p5", OleDbType.Integer).Value = reorder;

            cmd.Parameters.Add(
                "@p6", OleDbType.Integer).Value = id;

            return cmd.ExecuteNonQuery() > 0;
        }

        public static bool DeleteProduct(int id)
        {
            using var c = GetConnection();
            c.Open();

            EnsureProductsTable(c);

            using var cmd = new OleDbCommand(
                "DELETE FROM Products WHERE ProductID=?",
                c);

            cmd.Parameters.Add(
                "@p1", OleDbType.Integer).Value = id;

            return cmd.ExecuteNonQuery() > 0;
        }
    }
}
